
export default (state = {}, action ) => {
    switch(action.type){
        case 'UPDATE_MOVE':
            return state
        default:
            return state
    }
}