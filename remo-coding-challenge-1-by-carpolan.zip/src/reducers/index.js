
import { combineReducers } from "redux";

import data from "./gameDataReducer";

export default combineReducers({
  data
});